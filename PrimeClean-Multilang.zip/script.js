const translations = {
  nl: {
    title: "PrimeClean Services",
    subtitle: "Professionele schoonmaakdiensten",
    description: "Wij bieden hoogwaardige schoonmaakdiensten voor woningen en bedrijven.",
    footer: "© 2025 PrimeClean Services"
  },
  fr: {
    title: "PrimeClean Services",
    subtitle: "Services de nettoyage professionnels",
    description: "Nous offrons des services de nettoyage de haute qualité pour maisons et entreprises.",
    footer: "© 2025 PrimeClean Services"
  }
};

const select = document.getElementById("lang-select");
select.addEventListener("change", (e) => {
  const lang = e.target.value;
  document.getElementById("title").textContent = translations[lang].title;
  document.getElementById("subtitle").textContent = translations[lang].subtitle;
  document.getElementById("description").textContent = translations[lang].description;
  document.getElementById("footer").textContent = translations[lang].footer;
});
